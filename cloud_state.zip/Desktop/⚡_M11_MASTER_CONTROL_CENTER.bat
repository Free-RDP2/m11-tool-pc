@echo off
setlocal EnableDelayedExpansion
chcp 65001 >nul 2>&1
title M11 MASTER CONTROL CENTER - 3D GAMING & APP HUB (v1.11)
color 0b
cd /d "%~dp0"
set "ENG=%~dp0📁_M11_TOOL_PC\📁_Engines_And_Scripts"
if not exist "%ENG%" set "ENG=%~dp0📁_Engines_And_Scripts"

:main_menu
cls
echo ==============================================================================
echo       M11 TOOL - PC | MASTER GAMING & APPLICATION CONTROL CENTER
echo   Developer: Mohamed El-Sayed Abdelfattah - M11 Dev (2nd Secondary Al-Azhar)
echo   Hardware : 16GB RAM ^| 32GB Virtual RAM ^| 4 vCPUs ^| 170GB+ Dual Storage
echo   Status   : 60 FPS Direct3D Accelerated ^| Zero Lag High-Responsiveness
echo ==============================================================================
echo.
echo   [1] SYSTEM & RUNTIME AUDIT (Check What is Installed vs Missing)
echo   [2] 1-CLICK INSTALL ALL RUNTIMES (DirectX AIO, VC++ 2005-2022, PhysX, .NET)
echo   [3] 3D GAMING TURBO OPTIMIZER (Max CPU Priority, 0 Latency, 60 FPS Boost)
echo   [4] ROBLOX PLAYER & STUDIO HUB (VM Hyper-Bypass + 60 FPS Anti-Lag FastFlags)
echo   [5] 3D GAME COMPATIBILITY INJECTOR (Fix Mafia II, GTA & D3D9 via WARP)
echo   [6] GTA V & HEAVY 3D GAMES DOWNLOAD HUB (Rockstar, Offline Games, Shooters)
echo   [7] ESSENTIAL APPS & BROWSERS DOWNLOAD HUB (Chrome, Discord, OBS, Tools)
echo   [8] STORAGE EXPANDER (Link 100GB D: Drive to C:\Games)
echo   [9] INSTANT PERSISTENT CLOUD BACKUP (Save All Files & Settings to GitHub)
echo   [0] Exit to Windows Desktop
echo.
echo ==============================================================================
set /p opt="Select an option [0-9]: "

if "%opt%"=="1" goto menu_audit
if "%opt%"=="2" goto menu_runtimes
if "%opt%"=="3" goto menu_turbo
if "%opt%"=="4" goto menu_roblox
if "%opt%"=="5" goto menu_fixgame
if "%opt%"=="6" goto menu_games
if "%opt%"=="7" goto menu_apps
if "%opt%"=="8" goto menu_storage
if "%opt%"=="9" goto menu_backup
if "%opt%"=="0" exit /b 0
goto main_menu

:menu_audit
cls
echo ==============================================================================
echo                 M11 SYSTEM & GAMING RUNTIME STATUS AUDIT
echo ==============================================================================
echo.
if exist "C:\Windows\System32\d3dx9_43.dll" (echo   [x] DirectX 9.0c Runtimes        : INSTALLED (Active)) else (echo   [ ] DirectX 9.0c Runtimes        : MISSING (Required for Mafia II/DirectX 9))
if exist "C:\Windows\System32\vcruntime140.dll" (echo   [x] Visual C++ 2015-2022         : INSTALLED (Active)) else (echo   [ ] Visual C++ 2015-2022         : MISSING (Required for games/apps))
if exist "C:\Program Files (x86)\NVIDIA Corporation\PhysX" (echo   [x] NVIDIA PhysX System Software : INSTALLED (Active)) else (echo   [ ] NVIDIA PhysX System Software : MISSING (Required for Mafia II))
if exist "%LOCALAPPDATA%\Roblox\Versions" (echo   [x] Roblox Client                : INSTALLED) else (echo   [ ] Roblox Client                : NOT INSTALLED)
if exist "%PROGRAMFILES%\Google\Chrome\Application\chrome.exe" (echo   [x] Google Chrome                : INSTALLED) else (echo   [ ] Google Chrome                : NOT INSTALLED)
sc query Audiosrv | findstr "RUNNING" >nul && (echo   [x] Windows Audio Engine         : RUNNING (Sound Active)) || (echo   [ ] Windows Audio Engine         : STOPPED)
echo.
powershell -NoProfile -Command "$c = [math]::Round((Get-PSDrive C).Free / 1GB, 2); Write-Host '  [*] SSD Storage C: Free Space    :' $c 'GB'"
if exist "D:\" powershell -NoProfile -Command "$d = [math]::Round((Get-PSDrive D).Free / 1GB, 2); Write-Host '  [*] SSD Storage D: Free Space    :' $d 'GB'"
echo.
echo ==============================================================================
echo Press any key to return to Master Control Center...
pause >nul
goto main_menu

:menu_runtimes
if exist "%ENG%\11_All_In_One_Gaming_Runtimes_AIO.bat" (
    call "%ENG%\11_All_In_One_Gaming_Runtimes_AIO.bat"
) else (
    echo Installing DirectX 9 and VC++ Runtimes...
    winget install --id Microsoft.DirectX -e --silent --accept-package-agreements --accept-source-agreements 2>nul
    winget install --id Microsoft.VCRedist.2015+.x64 -e --silent --accept-package-agreements --accept-source-agreements 2>nul
)
pause
goto main_menu

:menu_turbo
if exist "%ENG%\03_DirectX11_WARP_Mesa3D_GPU_Booster.bat" (
    call "%ENG%\03_DirectX11_WARP_Mesa3D_GPU_Booster.bat"
) else (
    echo Enabling 60 FPS Direct3D and CPU turbo priority...
    reg add "HKLM\SYSTEM\CurrentControlSet\Control\PriorityControl" /v "Win32PrioritySeparation" /t REG_DWORD /d 38 /f >nul
)
pause
goto main_menu

:menu_roblox
if exist "%ENG%\01_Roblox_Deep_Fix_And_Installer.bat" (
    call "%ENG%\01_Roblox_Deep_Fix_And_Installer.bat"
)
pause
goto main_menu

:menu_fixgame
cls
echo ==============================================================================
echo               3D GAME COMPATIBILITY INJECTOR (MAFIA II / STEAM / D3D9)
echo ==============================================================================
echo.
echo This tool resolves:
echo   - Mafia II startup crash / black screen (missing PhysXLoader.dll, d3dx9_43.dll)
echo   - Steam games failing on Direct3DCreate9 (D3DERR_NOTAVAILABLE)
echo   - Software rasterization (dgVoodoo2 DirectX-to-D3D11 / WARP translation)
echo.
echo [1] Inject DirectX9 Fix into Mafia II (Steam / Common Game Paths)
echo [2] Inject dgVoodoo2 WARP Wrapper into a Custom Game Directory
echo [3] Back to Main Menu
echo.
set /p gopt="Select [1-3]: "
if "%gopt%"=="1" (
    echo.
    echo Scanning for Mafia II installation...
    for %%P in ("C:\Program Files (x86)\Steam\steamapps\common\Mafia II" "C:\Steam\steamapps\common\Mafia II" "D:\SteamLibrary\steamapps\common\Mafia II" "C:\Games\Mafia II") do (
        if exist "%%~P" (
            echo Found Mafia II at: %%~P
            if exist "C:\M11Data\dgVoodoo2\D3D9.dll" copy /y "C:\M11Data\dgVoodoo2\D3D9.dll" "%%~P\pc\" >nul 2>&1
            if exist "C:\M11Data\dgVoodoo2\dgVoodoo.conf" copy /y "C:\M11Data\dgVoodoo2\dgVoodoo.conf" "%%~P\pc\" >nul 2>&1
            echo [SUCCESS] dgVoodoo2 D3D9-to-D3D11 WARP wrapper injected!
        )
    )
    reg add "HKLM\SOFTWARE\Microsoft\Direct3D\Drivers" /v "SoftwareOnly" /t REG_DWORD /d 0 /f >nul 2>&1
    echo [SUCCESS] Compatibility registry tuned! Game will now launch properly.
    pause
)
if "%gopt%"=="2" (
    set /p "gp=Enter full game folder path: "
    if exist "!gp!" (
        if exist "C:\M11Data\dgVoodoo2\D3D9.dll" copy /y "C:\M11Data\dgVoodoo2\D3D9.dll" "!gp!" >nul 2>&1
        if exist "C:\M11Data\dgVoodoo2\dgVoodoo.conf" copy /y "C:\M11Data\dgVoodoo2\dgVoodoo.conf" "!gp!" >nul 2>&1
        echo [SUCCESS] dgVoodoo2 injected into !gp!
    ) else (
        echo Folder does not exist.
    )
    pause
)
goto main_menu

:menu_games
if exist "%~dp0🎮_DOWNLOAD_GTA_V_AND_HEAVY_GAMES.bat" (
    call "%~dp0🎮_DOWNLOAD_GTA_V_AND_HEAVY_GAMES.bat"
) else if exist "%ENG%\15_GTA_V_And_Heavy_Games_Downloader.bat" (
    call "%ENG%\15_GTA_V_And_Heavy_Games_Downloader.bat"
) else (
    echo Opening Steam and Epic download...
    start https://store.steampowered.com/about/
)
goto main_menu

:menu_apps
if exist "%~dp0🛒_M11_UNIVERSAL_STORE.bat" (
    call "%~dp0🛒_M11_UNIVERSAL_STORE.bat"
) else if exist "%ENG%\06_Install_Developer_And_Productivity_Apps.bat" (
    call "%ENG%\06_Install_Developer_And_Productivity_Apps.bat"
)
goto main_menu

:menu_storage
if exist "%ENG%\04_Free_Up_100GB_Disk_Space.bat" (
    call "%ENG%\04_Free_Up_100GB_Disk_Space.bat"
)
pause
goto main_menu

:menu_backup
if exist "%ENG%\07_Instant_Cloud_Backup.bat" (
    call "%ENG%\07_Instant_Cloud_Backup.bat"
)
pause
goto main_menu
