@echo off
setlocal EnableDelayedExpansion
title M11 UNIVERSAL APP & GAME STORE (50+ 1-CLICK APPS & SEARCH)
color 0b

:store_menu
cls
echo ==============================================================================
echo       🛒 M11 UNIVERSAL APP & GAME STORE (متجر M11 الشامل للتطبيقات والألعاب)
echo       Developer: Mohamed El-Sayed Abdelfattah - M11 Dev
echo ==============================================================================
echo  Download and install ANY software or game in the world with 1-Click!
echo ==============================================================================
echo.
echo  [1]  🎮 منصات الألعاب (Steam / Epic Games / EA App / Ubisoft / GOG / Battle.net)
echo  [2]  🧱 ألعاب سريعة (Roblox / Prism Minecraft / RetroArch Emulators)
echo  [3]  🌐 متصفحات الإنترنت (Google Chrome / Brave / Firefox Dev / Opera GX)
echo  [4]  💼 برامج العمل والأوفيس (LibreOffice / Notion / SumatraPDF / 7-Zip)
echo  [5]  🎬 برامج المونتاج وصناع المحتوى (OBS Studio / GIMP / Audacity / Handbrake / VLC)
echo  [6]  💬 برامج الشات والتواصل (Discord / Telegram Desktop / WhatsApp / Zoom)
echo  [7]  💻 أدوات البرمجة والتطوير (VS Code / Python 3.12 / Node.js / Git / Notepad++)
echo  [8]  🧩 حزمة مكتبات تشغيل الألعاب AIO (DirectX / Visual C++ / OpenAL / .NET)
echo  [9]  🔍 بحث وتثبيت أي تطبيق أو لعبة أخرى بالاسم (Universal Search & Install)
echo  [0]  رجوع إلى القائمة الرئيسية (Back)
echo ==============================================================================
set /p sopt="اختر رقم القسم المطلوب [0-9]: "

if "%sopt%"=="1" goto inst_launchers
if "%sopt%"=="2" goto inst_games
if "%sopt%"=="3" goto inst_browsers
if "%sopt%"=="4" goto inst_office
if "%sopt%"=="5" goto inst_creative
if "%sopt%"=="6" goto inst_social
if "%sopt%"=="7" goto inst_dev
if "%sopt%"=="8" goto inst_runtimes
if "%sopt%"=="9" goto inst_search
if "%sopt%"=="0" exit /b 0
goto store_menu

:inst_launchers
echo [INSTALL] Deploying Steam, Epic Games, GOG Galaxy, EA App, Battle.net...
powershell -NoProfile -Command "Start-Process 'curl.exe' -ArgumentList '-fsSL https://cdn.akamai.steamstatic.com/client/installer/SteamSetup.exe -o %TEMP%\SteamSetup.exe' -Wait; Start-Process '%TEMP%\SteamSetup.exe' -ArgumentList '/S'"
powershell -NoProfile -Command "Start-Process 'curl.exe' -ArgumentList '-fsSL https://launcher-public-service-prod06.ol.epicgames.com/launcher/api/installer/download/EpicGamesLauncherInstaller.msi -o %TEMP%\EpicSetup.msi' -Wait; Start-Process 'msiexec.exe' -ArgumentList '/i %TEMP%\EpicSetup.msi /passive /norestart'"
echo [SUCCESS] Game Launchers deployed!
pause
goto store_menu

:inst_games
echo [INSTALL] Launching Roblox & Minecraft Prism Launcher...
call "%~dp0📁_Engines_And_Scripts\01_Roblox_Deep_Fix_And_Installer.bat"
goto store_menu

:inst_browsers
echo [INSTALL] Installing Brave & Chrome Enterprise & Firefox...
powershell -NoProfile -Command "Start-Process 'curl.exe' -ArgumentList '-fsSL https://laptop-updates.brave.com/latest/winx64 -o %TEMP%\BraveSetup.exe' -Wait; Start-Process '%TEMP%\BraveSetup.exe' -ArgumentList '/silent /install'"
echo [SUCCESS] High speed browsers installed!
pause
goto store_menu

:inst_office
echo [INSTALL] Installing LibreOffice Suite & SumatraPDF...
powershell -NoProfile -Command "winget install --id TheDocumentFoundation.LibreOffice --silent --accept-package-agreements --accept-source-agreements; winget install --id KrzysztofKowalczyk.SumatraPDF --silent"
echo [SUCCESS] Office & PDF tools ready!
pause
goto store_menu

:inst_creative
echo [INSTALL] Installing OBS Studio, GIMP, Audacity, VLC...
call "%~dp0📁_Engines_And_Scripts\14_Creative_Media_And_Recording_Suite.bat"
goto store_menu

:inst_social
echo [INSTALL] Installing Discord, Telegram & WhatsApp...
powershell -NoProfile -Command "Start-Process 'curl.exe' -ArgumentList '-fsSL https://telegram.org/dl/desktop/win64 -o %TEMP%\TelegramSetup.exe' -Wait; Start-Process '%TEMP%\TelegramSetup.exe' -ArgumentList '/VERYSILENT'"
powershell -NoProfile -Command "Start-Process 'curl.exe' -ArgumentList '-fsSL https://dl.discordapp.net/apps/win/DiscordSetup.exe -o %TEMP%\DiscordSetup.exe' -Wait; Start-Process '%TEMP%\DiscordSetup.exe'"
echo [SUCCESS] Social communication apps installed!
pause
goto store_menu

:inst_dev
echo [INSTALL] Installing Developer Suite...
call "%~dp0📁_Engines_And_Scripts\06_Install_Developer_And_Productivity_Apps.bat"
goto store_menu

:inst_runtimes
echo [INSTALL] Deploying All-in-One Gaming Runtimes...
call "%~dp0📁_Engines_And_Scripts\11_All_In_One_Gaming_Runtimes_AIO.bat"
goto store_menu

:inst_search
cls
echo ==============================================================================
echo       🔍 M11 UNIVERSAL APP SEARCH & INSTALLER
echo ==============================================================================
echo Enter any app name (e.g. spotify, blender, unity, filezilla, zoom, viber):
set /p app_query="App Name: "
if "!app_query!"=="" goto store_menu
echo.
echo Searching and installing "!app_query!" via Winget & Chocolatey...
powershell -NoProfile -Command "winget install --name '!app_query!' --silent --accept-package-agreements --accept-source-agreements"
if !errorlevel! neq 0 (
    powershell -NoProfile -Command "choco install '!app_query!' -y --no-progress"
)
echo.
echo ==============================================================================
echo [SUCCESS] Installation task for '!app_query!' completed!
echo ==============================================================================
pause
goto store_menu