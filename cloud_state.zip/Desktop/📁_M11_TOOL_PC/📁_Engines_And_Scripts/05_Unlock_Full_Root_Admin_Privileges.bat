@echo off
title M11 UNLOCK FULL ROOT & ADMIN PRIVILEGES
color 0c
echo ==============================================================================
echo       M11 UNLOCK FULL ROOT & ADMIN PRIVILEGES (ZERO RESTRICTIONS)
echo       [?? ??? ??? ??????? ??????: ???? ????? ????????? - M11 Developer]
echo ==============================================================================
echo.
echo [1/3] Disabling UAC elevation prompts (EnableLUA=0)...
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v "EnableLUA" /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v "ConsentPromptBehaviorAdmin" /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v "PromptOnSecureDesktop" /t REG_DWORD /d 0 /f >nul 2>&1

echo [2/3] Disabling SmartScreen and open-file security warnings...
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" /v "SmartScreenEnabled" /t REG_SZ /d "Off" /f >nul 2>&1
setx SEE_MASK_NOZONECHECKS 1 /M >nul 2>&1

echo [3/3] Granting full ownership of C: drive to M11 Dev-Tool...
takeown /f "C:\M11Data" /r /d y >nul 2>&1
icacls "C:\M11Data" /grant "M11 Dev-Tool:(OI)(CI)F" /t /q >nul 2>&1

echo.
echo ==============================================================================
echo [SUCCESS] Full Root & Administrator Freedom Active! Zero restrictions!
echo ==============================================================================
pause
