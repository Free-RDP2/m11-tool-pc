@echo off
setlocal EnableDelayedExpansion
title M11 ROOT ADMIN UNLOCKER (v1.14)
color 0c
echo ==============================================================================
echo       M11 ROOT ADMIN UNLOCKER  -  full administrator rights
echo       Developer: Mohamed El-Sayed Abdelfattah - M11 Dev
echo ==============================================================================
echo.
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [*] Elevating to administrator...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs" >nul 2>&1
    exit /b
)
echo [1/4] Adding every M11 account to the Administrators group...
net localgroup Administrators "M11 Dev-Tool" /add >nul 2>&1
net localgroup Administrators "runneradmin" /add >nul 2>&1
net localgroup Administrators "%USERNAME%" /add >nul 2>&1
net localgroup "Remote Desktop Users" "M11 Dev-Tool" /add >nul 2>&1
net localgroup "Remote Desktop Users" "%USERNAME%" /add >nul 2>&1
net localgroup Administrators >nul 2>&1

echo [2/4] Removing the UAC elevation barrier (keep RDP sign-in smooth)...
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v EnableLUA /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v ConsentPromptBehaviorAdmin /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v FilterAdministratorToken /t REG_DWORD /d 1 /f >nul 2>&1

echo [3/4] Verifying membership...
whoami /groups | findstr /i "S-1-5-32-544" >nul 2>&1
if %errorlevel% equ 0 (echo     [OK] current session is in Administrators) else (echo     [INFO] sign out and in once - membership applies to new sessions)

echo [4/4] Done.
echo ==============================================================================
echo [SUCCESS] Full Unrestricted Administrator Privileges active!
echo ==============================================================================
pause
