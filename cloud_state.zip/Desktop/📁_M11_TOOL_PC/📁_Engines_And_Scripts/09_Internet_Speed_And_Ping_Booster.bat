@echo off
setlocal EnableDelayedExpansion
title M11 INTERNET SPEED & GAMING PING BOOSTER
color 0e
echo ==============================================================================
echo       M11 INTERNET SPEED & GAMING PING BOOSTER (Ultra Low Latency)
echo       Developer: Mohamed El-Sayed Abdelfattah - M11 Dev
echo ==============================================================================
echo.
echo [1/4] Applying TCP Optimizer (Disable Nagle's Algorithm for Gaming)...
for /f "tokens=*" %%k in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces"') do (
    reg add "%%k" /v "TcpAckFrequency" /t REG_DWORD /d 1 /f >nul 2>&1
    reg add "%%k" /v "TCPNoDelay" /t REG_DWORD /d 1 /f >nul 2>&1
)
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v "NetworkThrottlingIndex" /t REG_DWORD /d 4294967295 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v "SystemResponsiveness" /t REG_DWORD /d 0 /f >nul 2>&1

echo [2/4] Setting Lightning-Fast DNS (Cloudflare 1.1.1.1 & Google 8.8.8.8)...
powershell -NoProfile -Command "Get-NetAdapter | Where-Object { $_.Status -eq 'Up' } | ForEach-Object { Set-DnsClientServerAddress -InterfaceIndex $_.InterfaceIndex -ServerAddresses ('1.1.1.1', '8.8.8.8', '1.0.0.1') -ErrorAction SilentlyContinue }" >nul 2>&1

echo [3/4] Flushing DNS cache and resetting TCP/IP stack...
ipconfig /flushdns >nul 2>&1
netsh int ip reset >nul 2>&1

echo [4/4] Testing ping response to international datacenters...
ping 1.1.1.1 -n 3
echo.
echo ==============================================================================
echo [SUCCESS] Network and TCP stack optimized for ultra-low latency & 1000 Mbps!
echo ==============================================================================
pause