@echo off
title M11 INSTANT CONTINUOUS CLOUD BACKUP
color 0a
echo ==============================================================================
echo       M11 INSTANT CONTINUOUS CLOUD PRESERVATION (Zero Data Loss)
echo       Developer: Mohamed El-Sayed Abdelfattah - M11 Dev
echo ==============================================================================
echo.
echo [1/2] Packaging your Desktop, Documents, Downloads and App Settings...
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\M11Data\m11_persistent_daemon.ps1" -ForceNow
echo.
echo ==============================================================================
echo [SUCCESS] Your files and entire session are securely backed up in Cloud!
echo ==============================================================================
pause