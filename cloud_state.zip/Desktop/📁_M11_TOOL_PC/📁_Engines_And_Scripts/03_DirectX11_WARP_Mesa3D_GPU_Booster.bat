@echo off
title M11 DIRECTX 11 & MESA3D 60 FPS GPU BOOSTER
color 0a
echo ==============================================================================
echo       M11 DIRECTX 11 & MESA3D 60 FPS GPU BOOSTER
echo       [?? ??? ??? ??????? ??????: ???? ????? ????????? - M11 Developer]
echo ==============================================================================
echo.
echo [1/3] Enabling RemoteFX & Direct3D 11 hardware/software acceleration...
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" /v "bEnumerateHWBeforeSW" /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" /v "fEnableRemoteFX" /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" /v "Enable3d" /t REG_DWORD /d 1 /f >nul 2>&1

echo [2/3] Configuring Software OpenGL 4.5 & Vulkan rasterizer...
setx MESA_GL_VERSION_OVERRIDE 4.5 >nul 2>&1
setx MESA_GLSL_VERSION_OVERRIDE 450 >nul 2>&1
setx GALLIUM_DRIVER llvmpipe >nul 2>&1
setx LIBGL_ALWAYS_SOFTWARE 1 >nul 2>&1

echo [3/3] Direct3D 11 WARP acceleration is active for Roblox, Minecraft, Unity!
echo.
echo ==============================================================================
echo [SUCCESS] 60 FPS GPU Acceleration fully configured!
echo ==============================================================================
pause
