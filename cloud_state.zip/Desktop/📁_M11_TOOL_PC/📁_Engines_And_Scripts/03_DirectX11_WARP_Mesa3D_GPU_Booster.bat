@echo off
rem =====================================================================
rem  M11 self-elevation guard (v1.14) - engines need admin rights
rem =====================================================================
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -ArgumentList '%*' -Verb RunAs" >nul 2>&1
    exit /b
)
title M11 DIRECTX11 ^& WARP / MESA3D GPU TURBO ACCELERATOR
color 0e
echo [*] Enabling WARP Direct3D 11 multi-threading (4 Dedicated vCPUs)...
setx WARP_FORCE_CPU_CORES 4 /M >nul 2>&1
setx MESA_GL_THREAD true /M >nul 2>&1
setx GALLIUM_THREAD 4 /M >nul 2>&1
setx LIBGL_THROTTLE_REFRESH 0 /M >nul 2>&1
setx MESA_GL_VERSION_OVERRIDE 4.5 /M >nul 2>&1
setx GALLIUM_DRIVER llvmpipe /M >nul 2>&1

reg add "HKLM\SYSTEM\CurrentControlSet\Control\PriorityControl" /v "Win32PrioritySeparation" /t REG_DWORD /d 38 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Direct3D\Drivers" /v "SoftwareOnly" /t REG_DWORD /d 0 /f >nul 2>&1
echo [SUCCESS] 60 FPS Direct3D ^& OpenGL llvmpipe acceleration unlocked!
pause