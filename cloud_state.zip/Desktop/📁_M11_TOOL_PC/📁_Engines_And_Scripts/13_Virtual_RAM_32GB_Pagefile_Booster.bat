@echo off
setlocal EnableDelayedExpansion
title M11 32GB VIRTUAL RAM & MEMORY ACCELERATOR
color 0e
echo ==============================================================================
echo       M11 32GB VIRTUAL RAM & MEMORY ACCELERATOR (Zero Out-of-Memory)
echo       Developer: Mohamed El-Sayed Abdelfattah - M11 Dev
echo ==============================================================================
echo.
echo [1/3] Expanding Pagefile on High-Speed SSD to 32GB (32768 MB)...
wmic pagefilesetting where name="C:\\pagefile.sys" set InitialSize=32768,MaximumSize=32768 >nul 2>&1
if !errorlevel! neq 0 (
    wmic pagefilesetting create name="C:\\pagefile.sys",InitialSize=32768,MaximumSize=32768 >nul 2>&1
)

echo [2/3] Optimizing System Responsiveness and Paging Executive in Registry...
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" /v "LargeSystemCache" /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" /v "DisablePagingExecutive" /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v "SystemResponsiveness" /t REG_DWORD /d 0 /f >nul 2>&1

echo [3/3] Total Memory Allocation: 16 GB Physical RAM + 32 GB Virtual RAM = 48 GB Total!
echo.
echo ==============================================================================
echo [SUCCESS] 32GB Virtual RAM activated! Heavy games and Blender will never crash!
echo ==============================================================================
pause
