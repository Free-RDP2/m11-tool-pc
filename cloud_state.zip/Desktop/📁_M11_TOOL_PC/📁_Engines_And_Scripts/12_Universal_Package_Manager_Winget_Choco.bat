@echo off
setlocal EnableDelayedExpansion
title M11 UNIVERSAL PACKAGE MANAGER ENABLER (Winget & Chocolatey)
color 0b
echo ==============================================================================
echo       M11 UNIVERSAL PACKAGE MANAGERS (Winget & Chocolatey Bootstrap)
echo       Developer: Mohamed El-Sayed Abdelfattah - M11 Dev
echo ==============================================================================
echo.
echo [1/2] Installing Chocolatey Package Manager...
powershell -NoProfile -ExecutionPolicy Bypass -Command "[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072; iex ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))"

echo [2/2] Updating PATH and registering CLI commands...
set "PATH=%PATH%;%ALLUSERSPROFILE%\chocolatey\bin"
echo.
echo ==============================================================================
echo [SUCCESS] Winget & Chocolatey enabled!
echo You can now install ANY software in existence by typing:
echo choco install <name> -y   OR   winget install <name>
echo ==============================================================================
pause