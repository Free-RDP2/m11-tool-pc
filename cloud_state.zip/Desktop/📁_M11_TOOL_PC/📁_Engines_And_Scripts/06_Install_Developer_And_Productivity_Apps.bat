@echo off
rem =====================================================================
rem  M11 self-elevation guard (v1.14) - engines need admin rights
rem =====================================================================
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -ArgumentList '%*' -Verb RunAs" >nul 2>&1
    exit /b
)
title M11 WORKSTATION PRODUCTIVITY ^& DEV APPS INSTALLER
color 0a
echo ==============================================================================
echo       M11 PRODUCTIVITY ^& DEVELOPER APPS INSTALLER
echo       Developer: Mohamed El-Sayed Abdelfattah - M11 Dev
echo ==============================================================================
echo.
echo [1/4] Installing Google Chrome Enterprise 64-bit...
if exist "%TEMP%\chrome_enterprise.msi" (
    start "" msiexec.exe /i "%TEMP%\chrome_enterprise.msi" /qn /norestart
)

echo [2/4] Downloading Visual Studio Code (Silent 64-bit)...
curl.exe -fsSL "https://update.code.visualstudio.com/latest/win32-x64-user/stable" -o "%TEMP%\VSCodeUserSetup.exe"
start "" "%TEMP%\VSCodeUserSetup.exe" /verysilent /mergetasks="!runcode,addcontextmenufiles,addcontextmenufolders,associatewithfiles,addtopath"

echo [3/4] Downloading 7-Zip (64-bit)...
curl.exe -fsSL "https://www.7-zip.org/a/7z2408-x64.exe" -o "%TEMP%\7z_setup.exe"
start "" "%TEMP%\7z_setup.exe" /S

echo [4/4] Downloading VLC Media Player (64-bit)...
curl.exe -fsSL "https://get.videolan.org/vlc/3.0.21/win64/vlc-3.0.21-win64.exe" -o "%TEMP%\vlc_setup.exe"
start "" "%TEMP%\vlc_setup.exe" /S

echo.
echo ==============================================================================
echo [SUCCESS] Productivity and developer apps installed in background!
echo ==============================================================================
pause