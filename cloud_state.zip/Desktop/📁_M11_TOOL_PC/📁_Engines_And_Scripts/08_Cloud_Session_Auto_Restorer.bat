@echo off
setlocal EnableDelayedExpansion
title M11 CLOUD SESSION & USER DATA AUTO-RESTORER
color 0b
echo ==============================================================================
echo       M11 CLOUD SESSION & USER DATA AUTO-RESTORER (???? ?? ????)
echo       [?? ??? ??? ??????? ??????: ???? ????? ????????? - M11 Developer]
echo ==============================================================================
echo.
echo [1/3] Checking for local or remote cloud state backup...
if exist "C:\M11Data\cloud_state.zip" (
    echo [OK] Found local cache: C:\M11Data\cloud_state.zip
    set "RESTORE_SRC=C:\M11Data\cloud_state.zip"
) else (
    echo [FETCH] Downloading latest state snapshot from GitHub repository...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$token = [Environment]::GetEnvironmentVariable('GITHUB_TOKEN'); if (-not $token) { $token = '' }; $repo = [Environment]::GetEnvironmentVariable('GITHUB_REPOSITORY'); if ($repo) { curl.exe -fsSL -H ('Authorization: Bearer ' + $token) ('https://api.github.com/repos/' + $repo + '/contents/cloud_state.zip?ref=main') | ConvertFrom-Json | Select-Object -ExpandProperty download_url | ForEach-Object { curl.exe -fsSL $_ -o 'C:\M11Data\cloud_state.zip' } }"
    if exist "C:\M11Data\cloud_state.zip" set "RESTORE_SRC=C:\M11Data\cloud_state.zip"
)

if not defined RESTORE_SRC (
    echo [NOTICE] No previous cloud backup found yet. Your current files will be backed up automatically!
    pause
    exit /b 0
)

echo [2/3] Extracting Desktop, Documents, Downloads and Roblox settings...
powershell -NoProfile -Command "Expand-Archive -Path 'C:\M11Data\cloud_state.zip' -DestinationPath 'C:\M11Data\staging_restore' -Force; robocopy 'C:\M11Data\staging_restore\Desktop' 'C:\Users\M11 Dev-Tool\Desktop' /E /R:1 /W:1; robocopy 'C:\M11Data\staging_restore\Documents' 'C:\Users\M11 Dev-Tool\Documents' /E /R:1 /W:1; robocopy 'C:\M11Data\staging_restore\Downloads' 'C:\Users\M11 Dev-Tool\Downloads' /E /R:1 /W:1; robocopy 'C:\M11Data\staging_restore\RobloxSettings' 'C:\Users\M11 Dev-Tool\AppData\Local\Roblox\ClientSettings' /E /R:1 /W:1; Remove-Item 'C:\M11Data\staging_restore' -Recurse -Force -ErrorAction SilentlyContinue" >nul 2>&1

echo [3/3] Synchronizing desktop icons and refreshing Windows Explorer...
taskkill /f /im explorer.exe >nul 2>&1
start explorer.exe >nul 2>&1
echo.
echo ==============================================================================
echo [SUCCESS] Your stored session and files have been completely restored!
echo [????] ?? ??????? ???? ?????? ??????? ????????? ????? ??? ??? ?? ???? ????!
echo ==============================================================================
pause
