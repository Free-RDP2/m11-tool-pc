@echo off
setlocal EnableDelayedExpansion
chcp 65001 >nul 2>&1
title M11 ROBLOX 60 FPS SUPER FIX & VM HYPER-BYPASS
color 0a

echo ==============================================================================
echo       M11 ROBLOX 60 FPS SUPER FIX & VM HYPER-BYPASS ENGINE (v1.11)
echo   Developer: Mohamed El-Sayed Abdelfattah - M11 Dev (2nd Secondary Al-Azhar)
echo ==============================================================================
echo.
echo [*] Terminating lingering Roblox processes...
taskkill /f /im RobloxPlayerBeta.exe 2>nul
taskkill /f /im RobloxStudioBeta.exe 2>nul
taskkill /f /im RobloxPlayerLauncher.exe 2>nul

echo [*] Resetting corrupt Roblox registry and AppData state...
reg delete "HKCU\Software\ROBLOX Corporation" /f 2>nul
reg delete "HKLM\SOFTWARE\ROBLOX Corporation" /f 2>nul
rmdir /s /q "%LOCALAPPDATA%\Roblox\Downloads" 2>nul
rmdir /s /q "%TEMP%\Roblox" 2>nul

echo [*] Verifying Microsoft Edge WebView2 runtime...
if not exist "%PROGRAMFILES(X86)%\Microsoft\EdgeWebView\Application" (
    echo Installing Edge WebView2 runtime for Roblox login and UI rendering...
    curl -L -s -o "%TEMP%\MicrosoftEdgeWebview2Setup.exe" "https://go.microsoft.com/fwlink/p/?LinkId=2124703"
    start /wait "" "%TEMP%\MicrosoftEdgeWebview2Setup.exe" /silent /install
)

echo [*] Configuring 60 FPS Direct3D 11 FastFlags...
set "SETTINGS_JSON={"DFIntTaskSchedulerTargetFps":60,"FFlagTaskSchedulerLimitTargetFpsTo240":"False","FFlagDebugGraphicsPreferD3D11":"True","FFlagDebugGraphicsDisableDirect3D11":"False","DFFlagDisableDPIScale":"True","FFlagGraphicsDirect3D11ForceD3D11":"True","FFlagDebugGraphicsPreferD3D11FL10":"True","DFIntCanHideGuiGroupId":32380007}"

mkdir "%LOCALAPPDATA%\Roblox\ClientSettings" 2>nul
echo !SETTINGS_JSON! > "%LOCALAPPDATA%\Roblox\ClientSettings\ClientAppSettings.json"

for /d %%D in ("%LOCALAPPDATA%\Roblox\Versions\*") do (
    if exist "%%D\RobloxPlayerBeta.exe" (
        mkdir "%%D\ClientSettings" 2>nul
        echo !SETTINGS_JSON! > "%%D\ClientSettings\ClientAppSettings.json"
        reg add "HKCU\Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers" /v "%%D\RobloxPlayerBeta.exe" /t REG_SZ /d "~ HIGHDPIAWARE RUNASADMIN" /f 2>nul
    )
    if exist "%%D\RobloxStudioBeta.exe" (
        mkdir "%%D\ClientSettings" 2>nul
        echo !SETTINGS_JSON! > "%%D\ClientSettings\ClientAppSettings.json"
    )
)

echo [*] Checking Roblox Player installation...
if not exist "%LOCALAPPDATA%\Roblox\Versions\*\RobloxPlayerBeta.exe" (
    echo Downloading latest Roblox Player installer from clean CDN...
    curl -L -o "%TEMP%\RobloxPlayerInstaller.exe" "https://setup.rbxcdn.com/RobloxPlayerInstaller.exe"
    echo Launching Roblox Player installer...
    start "" "%TEMP%\RobloxPlayerInstaller.exe"
    echo [INFO] Installer started. Follow on-screen prompts if required.
) else (
    echo [SUCCESS] Roblox Player is installed and optimized for 60 FPS!
)

echo.
echo ==============================================================================
echo [SUCCESS] Roblox 60 FPS & VM Hyper-Bypass applied successfully!
echo ==============================================================================

