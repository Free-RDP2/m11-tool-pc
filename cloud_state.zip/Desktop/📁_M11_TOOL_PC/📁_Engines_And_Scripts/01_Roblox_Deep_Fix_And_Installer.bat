@echo off
setlocal EnableDelayedExpansion
title M11 ROBLOX DEEP FIX & 60 FPS LAUNCHER
color 0a
echo ==============================================================================
echo       M11 ROBLOX DEEP FIX & DIRECT3D 11 WARP ACCELERATOR
echo       [?? ??? ??? ??????? ??????: ???? ????? ????????? - M11 Developer]
echo ==============================================================================
echo.
echo [1/6] Cleaning corrupted registry locks and installer temp caches...
reg delete "HKCU\Software\ROBLOX Corporation" /f >nul 2>&1
reg delete "HKLM\Software\ROBLOX Corporation" /f >nul 2>&1
if exist "%TEMP%\Roblox" rmdir /s /q "%TEMP%\Roblox" >nul 2>&1
if exist "%LOCALAPPDATA%\Roblox\Downloads" rmdir /s /q "%LOCALAPPDATA%\Roblox\Downloads" >nul 2>&1

echo [2/6] Disabling dtrace anti-cheat triggers and starting Windows Audio...
sc.exe config dtrace start=disabled >nul 2>&1
net stop dtrace >nul 2>&1
net start audiosrv >nul 2>&1
net start AudioEndpointBuilder >nul 2>&1

echo [3/6] Pre-configuring Direct3D 11 WARP, 60 FPS Lock & DPI Settings...
set "RBLX_CFG=%LOCALAPPDATA%\Roblox\ClientSettings"
if not exist "%RBLX_CFG%" mkdir "%RBLX_CFG%" >nul 2>&1
(
echo {
echo   "FFlagDebugGraphicsDisableDirect3D11": "False",
echo   "FFlagDebugGraphicsPreferD3D11": "True",
echo   "FFlagDebugGraphicsPreferD3D11FL10": "True",
echo   "FFlagDebugDisableDirect3D12": "True",
echo   "FFlagDebugDisableVulkan": "True",
echo   "FFlagDebugGraphicsPreferOpenGL": "False",
echo   "DFFlagDisableDPIScale": "True",
echo   "DFIntTaskSchedulerTargetFps": 60,
echo   "FFlagTaskSchedulerLimitTargetFpsTo240": "True"
echo }
) > "%RBLX_CFG%\ClientAppSettings.json"

for /d %%D in ("%LOCALAPPDATA%\Roblox\Versions\*") do (
    if not exist "%%D\ClientSettings" mkdir "%%D\ClientSettings" >nul 2>&1
    copy /y "%RBLX_CFG%\ClientAppSettings.json" "%%D\ClientSettings\ClientAppSettings.json" >nul 2>&1
)

echo [4/6] Checking for installed Roblox Player...
set "FOUND_PLAYER="
for /r "%LOCALAPPDATA%\Roblox\Versions" %%F in (RobloxPlayerBeta.exe) do (
    if exist "%%F" set "FOUND_PLAYER=%%F"
)
for /r "C:\Program Files (x86)\Roblox\Versions" %%F in (RobloxPlayerBeta.exe) do (
    if exist "%%F" set "FOUND_PLAYER=%%F"
)

if defined FOUND_PLAYER (
    echo [OK] Roblox Player is already installed: "!FOUND_PLAYER!"
    echo Applying Windows 8 Compatibility and DPI Layer...
    reg add "HKCU\Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers" /v "!FOUND_PLAYER!" /t REG_SZ /d "~ RUNASADMIN WIN8RTM HIGHDPIAWARE" /f >nul 2>&1
    echo Launching Roblox Player at 60 FPS...
    start "" "!FOUND_PLAYER!"
    timeout /t 3 >nul
    exit /b 0
)

echo [5/6] Roblox Player not installed. Launching official 64-bit installer...
if exist "C:\M11Data\RobloxPlayerInstaller.exe" (
    copy /y "C:\M11Data\RobloxPlayerInstaller.exe" "%TEMP%\RobloxPlayerInstaller.exe" >nul 2>&1
)
if not exist "%TEMP%\RobloxPlayerInstaller.exe" (
    curl.exe -fsSL "https://setup.rbxcdn.com/RobloxPlayerInstaller.exe" -o "%TEMP%\RobloxPlayerInstaller.exe"
)
if not exist "%TEMP%\RobloxPlayerInstaller.exe" (
    powershell -NoProfile -Command "Invoke-WebRequest -Uri https://setup.rbxcdn.com/RobloxPlayerInstaller.exe -OutFile %TEMP%\RobloxPlayerInstaller.exe"
)

echo [6/6] Starting installer...
start "" "%TEMP%\RobloxPlayerInstaller.exe"
echo.
echo ==============================================================================
echo [SUCCESS] Official Roblox installer launched!
echo Wait for installation progress to complete, then rerun this tool to play!
echo ==============================================================================
pause
