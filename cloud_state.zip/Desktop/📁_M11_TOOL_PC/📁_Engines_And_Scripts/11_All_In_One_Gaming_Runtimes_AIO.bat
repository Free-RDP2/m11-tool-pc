@echo off
setlocal EnableDelayedExpansion
title M11 ALL-IN-ONE GAMING RUNTIMES (DirectX, Visual C++, .NET, OpenAL)
color 0a
echo ==============================================================================
echo       M11 ALL-IN-ONE GAMING RUNTIMES DEPLOYER (Zero Missing DLLs)
echo       Developer: Mohamed El-Sayed Abdelfattah - M11 Dev
echo ==============================================================================
echo.
echo [1/4] Installing Visual C++ 2015-2022 (x86 & x64)...
curl.exe -fsSL "https://aka.ms/vs/17/release/vc_redist.x64.exe" -o "%TEMP%\vc_redist.x64.exe"
curl.exe -fsSL "https://aka.ms/vs/17/release/vc_redist.x86.exe" -o "%TEMP%\vc_redist.x86.exe"
start "" /wait "%TEMP%\vc_redist.x64.exe" /quiet /norestart
start "" /wait "%TEMP%\vc_redist.x86.exe" /quiet /norestart

echo [2/4] Installing DirectX End-User Runtime Web Installer...
curl.exe -fsSL "https://download.microsoft.com/download/1/7/1/1718CCC7-BB6B-4F74-BE47-23420845B258/dxwebsetup.exe" -o "%TEMP%\dxwebsetup.exe"
start "" /wait "%TEMP%\dxwebsetup.exe" /Q

echo [3/4] Installing .NET Desktop Runtime 8.0...
curl.exe -fsSL "https://aka.ms/dotnet/8.0/windowsdesktop-runtime-win-x64.exe" -o "%TEMP%\dotnet8.exe"
start "" /wait "%TEMP%\dotnet8.exe" /quiet /norestart

echo [4/4] Installing OpenAL 3D Audio Library...
curl.exe -fsSL "https://openal.org/downloads/oalinst.zip" -o "%TEMP%\oalinst.zip"
powershell -NoProfile -Command "Expand-Archive -Path '%TEMP%\oalinst.zip' -DestinationPath '%TEMP%\oalinst' -Force; Start-Process '%TEMP%\oalinst\oalinst.exe' -ArgumentList '/s' -Wait" >nul 2>&1

echo.
echo ==============================================================================
echo [SUCCESS] All Gaming Runtimes (DirectX, VC++, .NET, OpenAL) are fully active!
echo Every game in the world will launch without any missing DLL errors!
echo ==============================================================================
pause
