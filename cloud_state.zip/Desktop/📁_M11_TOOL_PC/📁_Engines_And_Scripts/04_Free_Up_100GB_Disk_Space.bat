@echo off
title M11 FREE UP 100GB SSD SPACE
color 0b
echo ==============================================================================
echo       M11 STORAGE EXPANDER - UNLOCK 100GB+ FREE SSD STORAGE
echo       [?? ??? ??? ??????? ??????: ???? ????? ????????? - M11 Developer]
echo ==============================================================================
echo.
echo [1/4] Purging bloated Android SDK caches (~18GB)...
if exist "C:\Android" rmdir /s /q "C:\Android" >nul 2>&1

echo [2/4] Purging unneeded runner language toolcaches (~25GB)...
if exist "C:\hostedtoolcache\windows\Go" rmdir /s /q "C:\hostedtoolcache\windows\Go" >nul 2>&1
if exist "C:\hostedtoolcache\windows\Ruby" rmdir /s /q "C:\hostedtoolcache\windows\Ruby" >nul 2>&1
if exist "C:\hostedtoolcache\windows\Java_Temurin-Hotspot_jdk" rmdir /s /q "C:\hostedtoolcache\windows\Java_Temurin-Hotspot_jdk" >nul 2>&1
if exist "C:\hostedtoolcache\windows\PyPy" rmdir /s /q "C:\hostedtoolcache\windows\PyPy" >nul 2>&1

echo [3/4] Purging Windows temp files and download caches...
del /q /f /s "%TEMP%\*" >nul 2>&1
del /q /f /s "C:\Windows\Temp\*" >nul 2>&1

echo [4/4] Calculating new free space on C: drive...
powershell -NoProfile -Command "$f = [math]::Round((Get-PSDrive C).Free / 1GB, 2); Write-Host '>>> Available Free SSD Space: ' $f ' GB! <<<' -ForegroundColor Green"
echo.
echo ==============================================================================
echo [SUCCESS] Up to 100GB+ of high-speed SSD storage is now unlocked and available!
echo ==============================================================================
pause
