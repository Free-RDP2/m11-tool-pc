@echo off
rem =====================================================================
rem  M11 self-elevation guard (v1.14) - engines need admin rights
rem =====================================================================
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -ArgumentList '%*' -Verb RunAs" >nul 2>&1
    exit /b
)
setlocal EnableDelayedExpansion
title M11 RDP TWO-WAY AUDIO ^& VIRTUAL MICROPHONE ENABLER
color 0a
echo ==============================================================================
echo       M11 RDP TWO-WAY AUDIO ^& VIRTUAL MICROPHONE ENABLER
echo       Developer: Mohamed El-Sayed Abdelfattah - M11 Dev
echo ==============================================================================
echo.
echo [1/3] Enabling RDP Remote Audio Recording (Microphone Redirection)...
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" /v "fDisableAudioCapture" /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" /v "fDisableAudioCapture" /t REG_DWORD /d 0 /f >nul 2>&1

echo [2/3] Restarting Windows Audio Services (Audiosrv ^& AudioEndpointBuilder)...
net stop Audiosrv >nul 2>&1
net stop AudioEndpointBuilder >nul 2>&1
sc.exe config Audiosrv start=auto >nul 2>&1
sc.exe config AudioEndpointBuilder start=auto >nul 2>&1
net start AudioEndpointBuilder >nul 2>&1
net start Audiosrv >nul 2>&1

echo [3/3] Setting high quality audio playback codec for RDP...
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Terminal Server\TSAudioRedirection" /v "EnableAudio" /t REG_DWORD /d 1 /f >nul 2>&1
echo.
echo ==============================================================================
echo [SUCCESS] Two-way high-fidelity audio and microphone redirection enabled!
echo Now you can talk in Discord and in-game voice chat over Remote Desktop!
echo ==============================================================================
pause