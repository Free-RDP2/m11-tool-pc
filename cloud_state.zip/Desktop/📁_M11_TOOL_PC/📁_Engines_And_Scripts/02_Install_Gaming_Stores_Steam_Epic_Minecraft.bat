@echo off
title M11 GAMING STORES & LAUNCHERS DEPLOYER
color 0e
echo ==============================================================================
echo       M11 GAMING STORES DEPLOYER (Steam / Epic Games / Minecraft / Discord)
echo       [?? ??? ??? ??????? ??????: ???? ????? ????????? - M11 Developer]
echo ==============================================================================
echo.
echo [1/4] Installing Steam Client...
curl.exe -fsSL "https://cdn.akamai.steamstatic.com/client/installer/SteamSetup.exe" -o "%TEMP%\SteamSetup.exe"
start "" "%TEMP%\SteamSetup.exe" /S

echo [2/4] Downloading Epic Games Launcher Installer...
curl.exe -fsSL "https://launcher-public-service-prod06.ol.epicgames.com/launcher/api/installer/download/EpicGamesLauncherInstaller.msi" -o "%TEMP%\EpicGamesLauncherInstaller.msi"
start "" msiexec.exe /i "%TEMP%\EpicGamesLauncherInstaller.msi" /passive /norestart

echo [3/4] Downloading Discord Setup...
curl.exe -fsSL "https://dl.discordapp.net/apps/win/DiscordSetup.exe" -o "%TEMP%\DiscordSetup.exe"
start "" "%TEMP%\DiscordSetup.exe"

echo [4/4] Downloading Prism Launcher (Minecraft 60 FPS Sandbox)...
curl.exe -fsSL "https://github.com/PrismLauncher/PrismLauncher/releases/latest/download/PrismLauncher-Windows-MSVC-Setup.exe" -o "%TEMP%\PrismLauncherSetup.exe"
start "" "%TEMP%\PrismLauncherSetup.exe" /S

echo.
echo ==============================================================================
echo [SUCCESS] Gaming Stores & Launchers are deploying cleanly in background!
echo ==============================================================================
pause
