@echo off
title M11 GAMING STORES INSTALLER
color 0d
echo ==============================================================================
echo        M11 GAMING STORES (Steam, Epic Games, Minecraft Launcher)
echo ==============================================================================
echo.
echo [1] Install Steam (Valve Official)
echo [2] Install Epic Games Store
echo [3] Install Minecraft Bedrock & Java Launcher
echo [4] Install All 3 Gaming Stores
echo.
set /p sopt="Select an option [1-4]: "
if "%sopt%"=="1" winget install --id Valve.Steam -e --silent --accept-package-agreements --accept-source-agreements
if "%sopt%"=="2" winget install --id EpicGames.EpicGamesLauncher -e --silent --accept-package-agreements --accept-source-agreements
if "%sopt%"=="3" winget install --id Mojang.MinecraftLauncher -e --silent --accept-package-agreements --accept-source-agreements
if "%sopt%"=="4" (
    winget install --id Valve.Steam -e --silent --accept-package-agreements --accept-source-agreements
    winget install --id EpicGames.EpicGamesLauncher -e --silent --accept-package-agreements --accept-source-agreements
    winget install --id Mojang.MinecraftLauncher -e --silent --accept-package-agreements --accept-source-agreements
)
pause
