@echo off
rem =====================================================================
rem  M11 self-elevation guard (v1.14) - engines need admin rights
rem =====================================================================
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -ArgumentList '%*' -Verb RunAs" >nul 2>&1
    exit /b
)
setlocal EnableDelayedExpansion
title M11 CREATIVE, RECORDING ^& MEDIA SUITE
color 0a
echo ==============================================================================
echo       M11 CREATIVE ^& STREAMING SUITE (OBS Studio / GIMP / Audacity / VLC)
echo       Developer: Mohamed El-Sayed Abdelfattah - M11 Dev
echo ==============================================================================
echo.
echo [1/4] Installing OBS Studio (Screen Recording ^& Gameplay Streamer)...
curl.exe -fsSL "https://cdn-fastly.obsproject.com/downloads/OBS-Studio-30.2.3-Windows-Installer.exe" -o "%TEMP%\obs_setup.exe"
start "" "%TEMP%\obs_setup.exe" /S

echo [2/4] Installing VLC Media Player...
curl.exe -fsSL "https://get.videolan.org/vlc/3.0.21/win64/vlc-3.0.21-win64.exe" -o "%TEMP%\vlc_setup.exe"
start "" "%TEMP%\vlc_setup.exe" /S

echo [3/4] Installing Audacity (Audio Recording ^& Voice FX)...
powershell -NoProfile -Command "winget install --id Audacity.Audacity --silent --accept-package-agreements --accept-source-agreements"

echo [4/4] Installing GIMP (Professional Image Editing ^& Photoshop Alternative)...
powershell -NoProfile -Command "winget install --id GIMP.GIMP --silent --accept-package-agreements --accept-source-agreements"

echo.
echo ==============================================================================
echo [SUCCESS] Media, Screen Recording, Audio and Design Suite deploying in background!
echo ==============================================================================
pause