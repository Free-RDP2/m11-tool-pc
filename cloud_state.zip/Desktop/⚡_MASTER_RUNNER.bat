@echo off
setlocal EnableDelayedExpansion
chcp 65001 >nul 2>&1
title M11 MASTER RUNNER v1.12 - مركز التحكم السحابي
color 0b

:: ---------- Smart path detection (works with Arabic/emoji AND mojibake names) ----------
set "TOOL="
for /d %%D in ("%~dp0*_M11_TOOL_PC") do set "TOOL=%%~fD"
if not defined TOOL for /d %%D in ("%~dp0..\*_M11_TOOL_PC") do set "TOOL=%%~fD"
if not defined TOOL if exist "%USERPROFILE%\Desktop\📁_M11_TOOL_PC" set "TOOL=%USERPROFILE%\Desktop\📁_M11_TOOL_PC"
set "ENG="
if defined TOOL for /d %%E in ("%TOOL%\*_Engines_And_Scripts") do set "ENG=%%~fE"
if not defined ENG if exist "%~dp0📁_Engines_And_Scripts" set "ENG=%~dp0📁_Engines_And_Scripts"
if not defined ENG for /d %%E in ("%~dp0*_Engines_And_Scripts") do set "ENG=%%~fE"

:main_menu
cls
echo ==============================================================================
echo         M11 MASTER RUNNER v1.12  -  مركز التحكم الكامل بالسيرفر السحابي
echo     المطور: محمد السيد عبدالفتاح (M11 Dev)  ^|  Windows Server 2025 Datacenter
echo ==============================================================================
echo   [1]   تشغيل كل المحركات معا (MANDATORY - اختره اول مرة)
echo   [2]   اصلاح روبلوكس وتثبيت 60 فريم + تخطي الحظر
echo   [3]   تثبيت كل مكتبات الالعاب (DirectX / VC++ / PhysX)
echo   [4]   انترنت مفتوح بالكامل (Outlook + DNS 1.1.1.1)
echo   [5]   تفريغ 100 جيجا مساحة + ربط مشغل D:
echo   [6]   صلاحيات الروت الكاملة (Admin)
echo   [7]   تثبيت البرامج الاساسية (Chrome / Discord / VS Code / 7-Zip)
echo   [8]   متاجر الالعاب (Steam / Epic / Minecraft)
echo   [9]   مسرع البينج والانترنت
echo   [10]  صوت ومايك افتراضي للـ RDP
echo   [11]  الويندوز 32GB Virtual RAM
echo   [12]  مكتبة الرسم والمونتاج (OBS / GIMP / Audacity)
echo   [13]  مساحة العمل السحابية - متجر التطبيقات الشامل
echo   [14]  تحميل GTA V والالعاب الثقيلة
echo   [15]  حفظ بياناتك الان في السحابة (Backup)
echo   [16]  استرجاع بياناتك المحفوظة (Restore)
echo   [17]  فحص شامل للسيرفر (M11 SELF TEST)
echo   [0]   خروج
echo ==============================================================================
set /p opt="اكتب رقم الاختيار ثم اضغط Enter: "

if "%opt%"=="1" goto run_all
if "%opt%"=="2" goto eng_01
if "%opt%"=="3" goto eng_11
if "%opt%"=="4" goto net_unblock
if "%opt%"=="5" goto eng_04
if "%opt%"=="6" goto eng_05
if "%opt%"=="7" goto eng_06
if "%opt%"=="8" goto eng_02
if "%opt%"=="9" goto eng_09
if "%opt%"=="10" goto eng_10
if "%opt%"=="11" goto eng_13
if "%opt%"=="12" goto eng_14
if "%opt%"=="13" goto store
if "%opt%"=="14" goto gta
if "%opt%"=="15" goto backup
if "%opt%"=="16" goto restore
if "%opt%"=="17" goto selftest
if "%opt%"=="0" exit /b 0
echo [!] رقم غير صحيح. حاول مرة اخرى.
timeout /t 2 >nul
goto main_menu

:ensure_eng
if not exist "%ENG%\01_Roblox_Deep_Fix_And_Installer.bat" (
    echo [ERROR] لم يتم العثور على مجلد المحركات ^(Engines^).
    echo         ابحث عنه داخل مجلد M11 Tool واعد المحاولة.
    pause
    goto main_menu
)
goto :eof

:run_all
call :ensure_eng
echo [>>>] جاري تشغيل كل المحركات بالتسلسل...
call "%ENG%\04_Free_Up_100GB_Disk_Space.bat"
call "%ENG%\05_Unlock_Full_Root_Admin_Privileges.bat"
call "%ENG%\13_Virtual_RAM_32GB_Pagefile_Booster.bat"
call "%ENG%\11_All_In_One_Gaming_Runtimes_AIO.bat"
call "%ENG%\03_DirectX11_WARP_Mesa3D_GPU_Booster.bat"
call "%ENG%\09_Internet_Speed_And_Ping_Booster.bat"
call "%ENG%\10_Audio_Microphone_Virtual_Cable.bat"
call "%ENG%\01_Roblox_Deep_Fix_And_Installer.bat"
call "%ENG%\06_Install_Developer_And_Productivity_Apps.bat"
echo.
echo [SUCCESS] تم تشغيل كل المحركات بنجاح!
pause
goto main_menu

:eng_01
call :ensure_eng
call "%ENG%\01_Roblox_Deep_Fix_And_Installer.bat"
pause
goto main_menu
:eng_02
call :ensure_eng
call "%ENG%\02_Install_Gaming_Stores_Steam_Epic_Minecraft.bat"
pause
goto main_menu
:eng_03
call :ensure_eng
call "%ENG%\03_DirectX11_WARP_Mesa3D_GPU_Booster.bat"
pause
goto main_menu
:eng_04
call :ensure_eng
call "%ENG%\04_Free_Up_100GB_Disk_Space.bat"
pause
goto main_menu
:eng_05
call :ensure_eng
call "%ENG%\05_Unlock_Full_Root_Admin_Privileges.bat"
pause
goto main_menu
:eng_06
call :ensure_eng
call "%ENG%\06_Install_Developer_And_Productivity_Apps.bat"
pause
goto main_menu
:eng_09
call :ensure_eng
call "%ENG%\09_Internet_Speed_And_Ping_Booster.bat"
pause
goto main_menu
:eng_10
call :ensure_eng
call "%ENG%\10_Audio_Microphone_Virtual_Cable.bat"
pause
goto main_menu
:eng_11
call :ensure_eng
call "%ENG%\11_All_In_One_Gaming_Runtimes_AIO.bat"
pause
goto main_menu
:eng_13
call :ensure_eng
call "%ENG%\13_Virtual_RAM_32GB_Pagefile_Booster.bat"
pause
goto main_menu
:eng_14
call :ensure_eng
call "%ENG%\14_Creative_Media_And_Recording_Suite.bat"
pause
goto main_menu

:store
if defined TOOL if exist "%TOOL%\🛒_M11_UNIVERSAL_STORE.bat" call "%TOOL%\🛒_M11_UNIVERSAL_STORE.bat"
if not exist "%TOOL%\🛒_M11_UNIVERSAL_STORE.bat" echo [ERROR] متجر التطبيقات غير موجود.
pause
goto main_menu

:gta
if defined TOOL if exist "%TOOL%\🎮_DOWNLOAD_GTA_V_AND_HEAVY_GAMES.bat" call "%TOOL%\🎮_DOWNLOAD_GTA_V_AND_HEAVY_GAMES.bat"
if not exist "%TOOL%\🎮_DOWNLOAD_GTA_V_AND_HEAVY_GAMES.bat" echo [ERROR] محمل الالعاب غير موجود.
pause
goto main_menu

:backup
call :ensure_eng
call "%ENG%\07_Instant_Cloud_Backup.bat"
pause
goto main_menu

:restore
call :ensure_eng
call "%ENG%\08_Cloud_Session_Auto_Restorer.bat"
pause
goto main_menu

:net_unblock
echo [NET] فتح الانترنت وتغيير الـ DNS...
reg add "HKLM\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A7-37EF-4b3f-8CFC-4F3A74704073}" /v "IsInstalled" /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A8-37EF-4b3f-8CFC-4F3A74704073}" /v "IsInstalled" /t REG_DWORD /d 0 /f >nul 2>&1
powershell -NoProfile -Command "Get-NetAdapter | Where-Object Status -eq 'Up' | Set-DnsClientServerAddress -ServerAddresses ('1.1.1.1','8.8.8.8') -ErrorAction SilentlyContinue" >nul 2>&1
ipconfig /flushdns >nul 2>&1
echo [SUCCESS] تم فتح الانترنت بنجاح!
pause
goto main_menu

:selftest
if exist "%TOOL%\📁_Engines_And_Scripts\M11_SELF_TEST.bat" call "%TOOL%\📁_Engines_And_Scripts\M11_SELF_TEST.bat"
if not exist "%TOOL%\📁_Engines_And_Scripts\M11_SELF_TEST.bat" if exist "%ENG%\M11_SELF_TEST.bat" call "%ENG%\M11_SELF_TEST.bat"
pause
goto main_menu