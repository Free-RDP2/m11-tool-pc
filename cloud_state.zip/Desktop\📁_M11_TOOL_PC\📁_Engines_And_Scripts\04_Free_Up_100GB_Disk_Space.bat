@echo off
title M11 FREE UP 100GB DISK SPACE
color 0a
echo Freeing up disk space on C: drive...
rd /s /q "C:\Android" 2>nul
rd /s /q "C:\hostedtoolcache" 2>nul
del /q /f /s "%TEMP%\*" 2>nul
del /q /f /s "C:\Windows\Temp\*" 2>nul
if exist "D:\" (
    mkdir "D:\M11_ExtraData" 2>nul
    mklink /D "C:\ExtraStorage_100GB" "D:\M11_ExtraData" 2>nul
)
powershell -NoProfile -Command "$f = [math]::Round((Get-PSDrive C).Free / 1GB, 2); Write-Host 'Storage available on C: ' $f 'GB'"
pause