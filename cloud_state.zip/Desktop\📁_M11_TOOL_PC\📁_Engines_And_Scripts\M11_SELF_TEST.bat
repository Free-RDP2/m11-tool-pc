@echo off
chcp 65001 >nul 2>&1
title M11 SELF TEST - فحص شامل للسيرفر
color 0e
echo ==============================================================================
echo                     M11 SELF TEST REPORT  (v1.12)
echo ==============================================================================
echo.
echo [1] حالة حساب M11 Dev-Tool وصلاحياته:
net user "M11 Dev-Tool" 2>nul | findstr /i "Account active Local Group" 
echo.
echo [2] حالة التشغيل التلقائي (Auto-Logon):
reg query "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v AutoAdminLogon 2>nul
reg query "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v DefaultUserName 2>nul
echo.
echo [3] منفذ الـ RDP 3389 وحالة NLA:
netstat -ano | findstr :3389 | findstr LISTENING
reg query "HKLM\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" /v UserAuthentication 2>nul
echo.
echo [4] مساحة التخزين ووصلة المشغل D:
if exist C:\ExtraStorage_100GB (echo   [OK] C:\ExtraStorage_100GB موجودة) else (echo   [X] C:\ExtraStorage_100GB غير موجودة)
dir C:\ExtraStorage_100GB 2>nul | findstr /i "bytes free"
powershell -NoProfile -Command "'   Free on C: ' + [math]::Round((Get-PSDrive C).Free/1GB,1) + ' GB'"
echo.
echo [5] مكتبات الالعاب:
if exist "C:\Windows\System32\d3dx9_43.dll" (echo   [OK] DirectX 9 d3dx9_43.dll) else (echo   [X] DirectX 9 غير مثبت - شغل الخيار [3])
if exist "C:\Program Files (x86)\NVIDIA Corporation\PhysX" (echo   [OK] NVIDIA PhysX) else (echo   [X] PhysX غير مثبت)
dir C:\M11Data\dgVoodoo2 2>nul | findstr /i "dgVoodoo D3D9 PhysXLoader" || echo   [X] مجلد dgVoodoo2 فارغ!
echo.
echo [6] winget / choco:
where winget 2>nul || echo   [X] winget غير متاح على الـ PATH
where choco 2>nul || echo   [i] chocolatey غير مثبت
echo.
echo [7] النفق السحابي (Tailscale):
"C:\Program Files\Tailscale\tailscale.exe" status 2>nul | findstr /i "100." || echo   [i] Tailscale ليس متصلا في هذه اللحظة
echo.
echo [8] الملفات المنشورة على سطح المكتب:
dir "C:\Users\Public\Desktop" /b 2>nul
echo.
echo ==============================================================================
echo   للتقرير الكامل انسخ هذه الشاشة وارسلها للمطور (M11 Dev).
echo ==============================================================================